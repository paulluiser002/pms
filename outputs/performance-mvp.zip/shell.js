/* Product-family application shell: sidebar search, company switcher, and profile menu. */
let pmsSidebarQuery='',pmsCompanyOpen=false,pmsProfileRoleMenu=false;
const pmsShellIcons={
  Dashboard:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
  Goals:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="m15 9 5-5M16 4h4v4"/></svg>',
  Reviews:'<svg viewBox="0 0 24 24"><path d="M7 3h10a2 2 0 0 1 2 2v16l-7-3-7 3V5a2 2 0 0 1 2-2Z"/><path d="m9 10 2 2 4-4"/></svg>',
  Reports:'<svg viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
  Employees:'<svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  'My Team':'<svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M8.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM17 8l2 2 4-4"/></svg>'
};
function pmsIcon(name){return `<span class="ico pms-outline-icon">${pmsShellIcons[name]||pmsShellIcons.Reviews}</span>`}
function pmsLogoMark(){return '<svg class="pms-logo-mark" viewBox="0 0 48 48" aria-hidden="true"><path d="m24 3 10 6v11l-10 6-10-6V9Z"/><path d="m14 20 10 6v11l-10 6-10-6V26ZM34 20l10 6v11l-10 6-10-6V26Z"/></svg>'}
function pmsMenuIcon(type){const icons={profile:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',settings:'<circle cx="12" cy="12" r="3"/><path d="M19 15a2 2 0 0 0 .4 2.2l.1.1-2.2 2.2-.1-.1A2 2 0 0 0 15 19l-.3 1H9.3L9 19a2 2 0 0 0-2.2.4l-.1.1-2.2-2.2.1-.1A2 2 0 0 0 5 15l-1-.3V9.3L5 9a2 2 0 0 0-.4-2.2l-.1-.1 2.2-2.2.1.1A2 2 0 0 0 9 5l.3-1h5.4l.3 1a2 2 0 0 0 2.2-.4l.1-.1 2.2 2.2-.1.1A2 2 0 0 0 19 9l1 .3v5.4Z"/>',preview:'<path d="M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6Z"/><circle cx="12" cy="12" r="2.5"/>',logout:'<path d="M10 17l5-5-5-5M15 12H3M14 3h5a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5"/>'};return `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[type]}</svg>`}

function pmsBuildShell(){
  const sidebar=document.querySelector('aside');
  sidebar.className='pms-sidebar';
  sidebar.innerHTML=`<div class="pms-brand">${pmsLogoMark()}<div><strong>PMS<span>Dot</span>Net</strong><small>performance management system</small></div></div><div class="pms-company-host"><button id="pmsCompanyButton" class="pms-company-button" type="button" aria-haspopup="true" aria-expanded="false" onclick="pmsToggleCompany()"><span class="pms-company-avatar">MC</span><span class="pms-company-copy"><b>Mayon Consolidated Inc.</b><small>Main Company</small></span><i class="pms-company-status" aria-label="Active company"></i><svg class="pms-company-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="m7 9 5 5 5-5"/></svg></button><div id="pmsCompanyMenu" class="pms-company-menu" hidden></div></div><label class="pms-sidebar-search"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><input id="pmsSidebarSearch" type="search" placeholder="Search..." aria-label="Search accessible pages" autocomplete="off" oninput="pmsSidebarSearchInput(this.value)"></label><div class="navlabel">WORKSPACE</div><nav id="nav" aria-label="Workspace navigation"></nav><div class="sidefoot"></div>`;
  pmsRenderCompany();
}
function pmsEnsurePageHeader(){
  let host=$('#pmsPageHeader');
  if(!host){host=document.createElement('div');host.id='pmsPageHeader';host.setAttribute('aria-label','Page header');$('.pms-topbar').insertAdjacentElement('afterend',host)}
  return host;
}
function pmsSplitPageHeader(){
  const host=pmsEnsurePageHeader(),content=$('#content');
  host.replaceChildren();
  if(!content)return;
  const dashboard=content.querySelector(':scope > .pms-dashboard');
  const pageHeader=dashboard?.querySelector(':scope > .pms-dash-header')||content.querySelector(':scope > .pagehead');
  if(pageHeader)host.appendChild(pageHeader);
  const filterError=dashboard?.querySelector(':scope > .pms-dash-filter-error');
  if(filterError)host.appendChild(filterError);
}
function pmsAccessiblePages(){
  const pages=roleNav().filter(([name])=>name!=='Reviews').map(([name])=>({label:name,parent:'',action:`navigate('${name}')`,icon:name}));
  if(urHr())pages.splice(2,0,{label:'All Reviews',parent:'Reviews',action:"urGoTab('Reviews')",icon:'Reviews'},{label:'Templates',parent:'Reviews',action:"urGoTab('Templates')",icon:'Reviews'},{label:'Cycles',parent:'Reviews',action:"urGoTab('Cycles')",icon:'Reviews'});
  else pages.splice(viewRole==='Manager'?3:2,0,{label:'Reviews',parent:'',action:"navigate('Reviews')",icon:'Reviews'});
  return pages;
}
function pmsSidebar(){
  const term=pmsSidebarQuery.trim().toLowerCase();
  if(term){const matches=pmsAccessiblePages().filter(item=>`${item.parent} ${item.label}`.toLowerCase().includes(term));return `<div class="pms-nav-search-results">${matches.map(item=>`<button type="button" onclick="${item.action};pmsClearSidebarSearch()">${pmsIcon(item.icon)}<span>${item.parent?`<small>${esc(item.parent)}</small>`:''}${esc(item.label)}</span><b>›</b></button>`).join('')||'<p class="pms-nav-empty">No matching pages found</p>'}</div>`}
  const active=page==='Reviews';
  return roleNav().map(([name])=>{
    if(name!=='Reviews')return `<button type="button" class="${page===name?'active':''}" ${page===name?'aria-current="page"':''} onclick="navigate('${name}')">${pmsIcon(name)}<span>${esc(name)}</span></button>`;
    if(!urHr())return `<button type="button" class="${active?'active':''}" ${active?'aria-current="page"':''} onclick="navigate('Reviews')">${pmsIcon('Reviews')}<span>Reviews</span></button>`;
    const children=['Reviews','Templates','Cycles'];
    return `<div class="pms-nav-group"><button type="button" class="pms-nav-parent ${active?'pms-parent-current':''}" aria-expanded="${pmsReviewsOpen}" aria-controls="pms-review-subnav" onclick="pmsToggleReviews()">${pmsIcon('Reviews')}<span>Reviews</span><span class="pms-chevron">⌄</span></button><div id="pms-review-subnav" class="pms-subnav" ${pmsReviewsOpen?'':'hidden'}>${children.map(section=>`<button type="button" class="pms-subitem ${active&&urTab===section?'active':''}" ${active&&urTab===section?'aria-current="page"':''} onclick="urGoTab('${section}')"><span>${section==='Reviews'?'All Reviews':section}</span></button>`).join('')}</div></div>`;
  }).join('');
}
function pmsSidebarSearchInput(value){pmsSidebarQuery=value;if(urHr()&&value.trim())pmsReviewsOpen=true;$('#nav').innerHTML=pmsSidebar()}
function pmsClearSidebarSearch(){pmsSidebarQuery='';const input=$('#pmsSidebarSearch');if(input)input.value='';$('#nav').innerHTML=pmsSidebar()}
function pmsRenderCompany(){const menu=$('#pmsCompanyMenu'),button=$('#pmsCompanyButton');if(!menu||!button)return;menu.hidden=!pmsCompanyOpen;button.setAttribute('aria-expanded',String(pmsCompanyOpen));menu.innerHTML=`<div class="pms-company-menu-title">Switch Company</div><div class="pms-company-section">MAIN COMPANY</div><button class="pms-company-option selected" type="button" onclick="pmsSelectCompany()"><span class="pms-company-avatar">MC</span><span><b>Mayon Consolidated Inc.</b><small>Main Company</small></span><i>✓</i></button><div class="pms-company-section">SISTER COMPANIES</div><p class="pms-company-empty">No sister companies available</p>`}
function pmsToggleCompany(){pmsCompanyOpen=!pmsCompanyOpen;pmsHeaderMenu=null;pmsProfileRoleMenu=false;pmsRenderCompany();pmsRenderHeader()}
function pmsSelectCompany(){pmsCompanyOpen=false;pmsRenderCompany();toast('Mayon Consolidated Inc. selected')}

pmsRenderHeader=function(){
  const profile=$('#pmsProfileMenu'),notifications=$('#pmsNotificationsMenu');if(!profile||!notifications)return;
  const roles=['Employee','Manager','HR Administrator'],name=roleName();
  profile.innerHTML=`<div class="pms-profile-head"><span class="avatar">${initials(name)}</span><b>${esc(name)}</b><small>${esc(viewRole)}</small></div><div class="pms-profile-actions"><button type="button" onclick="pmsOpenProfile()">${pmsMenuIcon('profile')}<span>Profile</span></button><button type="button" onclick="pmsOpenAccountSettings()">${pmsMenuIcon('settings')}<span>Account Settings</span></button><div class="pms-preview-host"><button type="button" aria-haspopup="true" aria-expanded="${pmsProfileRoleMenu}" onclick="pmsToggleRolePreview(event)">${pmsMenuIcon('preview')}<span>Preview as User Type</span><b>›</b></button><div class="pms-role-menu" ${pmsProfileRoleMenu?'':'hidden'}><div class="pms-menu-title">PREVIEW AS USER TYPE</div>${roles.map(role=>`<button type="button" role="menuitemradio" aria-checked="${role===viewRole}" onclick="pmsSelectRole('${role}')"><span>${esc(role)}</span><span class="pms-selected-mark">${role===viewRole?'✓':''}</span></button>`).join('')}</div></div><div class="pms-profile-divider"></div><button type="button" onclick="pmsLogOut()">${pmsMenuIcon('logout')}<span>Log out</span></button></div>`;
  const due=pmsNotificationRows();
  notifications.innerHTML=`<div class="pms-menu-title">NOTIFICATIONS</div>${data.pmsNotificationsEnabled?(due.length?`<div class="pms-notice-summary">${due.length} review${due.length===1?'':'s'} need${due.length===1?'s':''} your response</div>${due.slice(0,3).map(a=>`<button type="button" class="pms-notice-item" onclick="pmsCloseHeaderMenus();navigate('Reviews')"><b>${esc(urPerson(a.subject).name)} · ${esc(a.type)}</b><small>Due ${date(a.deadline)} · ${esc(urEffective(a))}</small></button>`).join('')}`:'<p class="pms-menu-empty">You’re up to date.</p>'):'<p class="pms-menu-empty">Notifications are turned off in Settings.</p>'}`;
  profile.hidden=pmsHeaderMenu!=='profile';notifications.hidden=pmsHeaderMenu!=='notifications';
  $('#pmsProfileButton').setAttribute('aria-expanded',String(pmsHeaderMenu==='profile'));$('#pmsNotificationsButton').setAttribute('aria-expanded',String(pmsHeaderMenu==='notifications'));$('#pmsProfileButton .avatar').textContent=initials(name);
};
pmsToggleHeaderMenu=function(which){pmsCompanyOpen=false;pmsRenderCompany();if(pmsHeaderMenu===which){pmsHeaderMenu=null;pmsProfileRoleMenu=false}else{pmsHeaderMenu=which;pmsProfileRoleMenu=false}pmsRenderHeader()};
pmsCloseHeaderMenus=function(){if(pmsHeaderMenu||pmsProfileRoleMenu){pmsHeaderMenu=null;pmsProfileRoleMenu=false;pmsRenderHeader()}};
function pmsToggleRolePreview(event){event.stopPropagation();pmsProfileRoleMenu=!pmsProfileRoleMenu;pmsRenderHeader()}
pmsSelectRole=function(role){if(!['Employee','Manager','HR Administrator'].includes(role))return;pmsHeaderMenu=null;pmsProfileRoleMenu=false;pmsSidebarQuery='';setRole(role)};
function pmsOpenProfile(){pmsCloseHeaderMenus();const personRecord=data.employees.find(e=>e[1]===roleName());modal('Profile','Your PMSDotNet profile.',`<div class="modalbody"><div class="pms-modal-profile"><span class="avatar">${initials(roleName())}</span><div><h2>${esc(roleName())}</h2><p>${esc(viewRole)}</p></div></div>${personRecord?`<div class="formgrid">${[['Employee ID',personRecord[0]],['Position',personRecord[2]],['Department',personRecord[3]],['Reports to',personRecord[4]]].map(([label,value])=>`<div><small>${label}</small><h2 style="margin-top:8px">${esc(value)}</h2></div>`).join('')}</div>`:'<div class="notice">Administrator profile · Organization-wide access</div>'}</div>`,`<button class="primary" onclick="closeModal()">Done</button>`)}
function pmsOpenAccountSettings(){pmsCloseHeaderMenus();pmsOpenSettings()}
function pmsLogOut(){pmsCloseHeaderMenus();modal('Log out','End this interactive preview session?',`<div class="modalbody"><p>This prototype does not connect to a production identity provider. Ending the preview returns the demo to the Employee dashboard.</p></div>`,`<button onclick="closeModal()">Stay signed in</button><button class="primary" onclick="closeModal();setRole('Employee');toast('Preview session reset')">End preview</button>`)}
function pmsRenderSideUser(){const foot=$('.sidefoot');if(!foot)return;foot.innerHTML=`<span class="avatar">${initials(roleName())}</span><div><b>${esc(roleName())}</b><small>${esc(viewRole)}</small></div>`}

const pmsShellBaseRender=render;
render=function(){pmsShellBaseRender();const nav=$('#nav');if(nav)nav.innerHTML=pmsSidebar();const search=$('#pmsSidebarSearch');if(search&&search.value!==pmsSidebarQuery)search.value=pmsSidebarQuery;pmsRenderSideUser();pmsRenderCompany();pmsRenderHeader();pmsSplitPageHeader()};
const pmsShellBaseNavigate=navigate;
navigate=function(destination){pmsCompanyOpen=false;pmsHeaderMenu=null;pmsProfileRoleMenu=false;pmsShellBaseNavigate(destination)};
const pmsShellBaseSetRole=setRole;
setRole=function(role){pmsSidebarQuery='';pmsCompanyOpen=false;pmsHeaderMenu=null;pmsProfileRoleMenu=false;pmsShellBaseSetRole(role)};
document.addEventListener('click',event=>{if(!event.target.closest('.pms-company-host')&&pmsCompanyOpen){pmsCompanyOpen=false;pmsRenderCompany()}});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&pmsCompanyOpen){pmsCompanyOpen=false;pmsRenderCompany()}});
pmsBuildShell();render();

/* Structured goal creation shares one form while retaining role and owner scope. */
let pmsGoalCreate=null;
function pmsGoalCreateOwners(){return viewRole==='Employee'?data.employees.filter(e=>e[0]===employeeId):scopedEmployees()}
function pmsGoalCreateCycles(){return UR.cycles.filter(c=>!['Cancelled','Completed'].includes(c.status)&&(urHr()||c.participants.some(id=>pmsGoalCreateOwners().some(e=>e[0]===id))))}
function pmsCreateGoal(){
  const owners=pmsGoalCreateOwners();
  pmsGoalCreate={role:viewRole,owner: viewRole==='Employee'?employeeId:'',milestoneId:0};
  modal('Create Goal','Define a goal and set the details below.',`<form id="pmsCreateGoalForm" class="pms-goal-builder">
    <div class="modalbody">
      <section class="pms-goal-section" aria-labelledby="pmsGoalContentHeading">
        <h3 id="pmsGoalContentHeading">Title &amp; Description</h3>
        <label for="pmsGoalName">Goal Name <span class="required">*</span></label>
        <input id="pmsGoalName" name="name" required maxlength="140" placeholder="e.g. Improve communication skills">
        <label for="pmsGoalDescription">Description</label>
        <textarea id="pmsGoalDescription" name="description" rows="3" maxlength="5000" placeholder="Describe the expected outcome of this goal."></textarea>
        <label id="pmsMilestoneLabel">Milestones</label><p class="pms-goal-helper">Break this goal into smaller action steps.</p>
        <div id="pmsGoalMilestones" aria-labelledby="pmsMilestoneLabel"></div>
        <button type="button" class="textbtn pms-add-milestone" onclick="pmsAddGoalMilestone()">+ Add Milestone</button>
      </section>
      <section class="pms-goal-section" aria-labelledby="pmsGoalOwnershipHeading">
        <h3 id="pmsGoalOwnershipHeading">Ownership &amp; Visibility</h3>
        <div class="pms-goal-fields pms-goal-fields-two">
          <div class="pms-goal-owner-host"><label id="pmsGoalOwnerLabel" for="pmsGoalOwnerSearch">Owned by <span class="required">*</span></label>
            <div class="pms-goal-owner-field"><span id="pmsGoalOwnerAvatar" class="avatar" aria-hidden="true">${viewRole==='Employee'?initials(roleName()):'⌕'}</span><input id="pmsGoalOwnerSearch" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="pmsGoalOwnerOptions" autocomplete="off" required placeholder="Search employees..." value="${viewRole==='Employee'?esc(roleName()):''}" onfocus="pmsSearchGoalOwners(this.value)" oninput="pmsGoalCreate.owner='';this.setCustomValidity('');pmsSearchGoalOwners(this.value)"><button type="button" aria-label="Show employee options" onclick="pmsSearchGoalOwners('');$('#pmsGoalOwnerSearch').focus()">⌄</button></div>
            <div id="pmsGoalOwnerOptions" role="listbox" aria-label="HRDotNet employees" hidden></div>
          </div>
          <div><label for="pmsGoalVisibility">Visible for</label><select id="pmsGoalVisibility" name="visibility"><option value="owner-manager">Owner and manager can see this</option></select><p class="pms-goal-helper">HR retains authorized administration access.</p></div>
        </div>
      </section>
      <section class="pms-goal-section" aria-labelledby="pmsGoalSettingsHeading">
        <h3 id="pmsGoalSettingsHeading">Additional Settings</h3>
        <div class="pms-goal-fields pms-goal-fields-three">
          <div><label for="pmsGoalCategory">Category / Goal Purpose <span class="required">*</span></label><select id="pmsGoalCategory" name="category" required><option value="">Select category</option>${['Quality','Delivery','Growth','Collaboration'].map(c=>`<option>${c}</option>`).join('')}</select></div>
          <div><label for="pmsGoalCycle">Cycle</label><select id="pmsGoalCycle" name="cycle"><option value="">No cycle</option>${pmsGoalCreateCycles().map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')}</select></div>
          <div><label for="pmsGoalDeadline">Deadline <span class="required">*</span></label><input id="pmsGoalDeadline" name="due" type="date" required></div>
        </div>
      </section>
      <p id="pmsGoalCreateError" class="urerror" role="alert"></p>
    </div>
    <div class="modalfoot"><button type="button" onclick="closeModal()">Cancel</button><button class="primary" type="submit">Save Goal</button></div>
  </form>`);
  $('#modal').classList.add('pms-create-goal-dialog');
  pmsAddGoalMilestone();
  $('#pmsCreateGoalForm').onsubmit=pmsSaveCreatedGoal;
  $('#pmsGoalOwnerSearch').addEventListener('keydown',event=>{if(event.key==='ArrowDown'){event.preventDefault();$('#pmsGoalOwnerOptions button')?.focus()}if(event.key==='Escape'){event.preventDefault();event.stopPropagation();pmsCloseGoalOwnerLookup()}});
  $('#pmsGoalName').focus();
}
function pmsAddGoalMilestone(){
  if(!pmsGoalCreate)return;
  const id=++pmsGoalCreate.milestoneId,row=document.createElement('div');row.className='pms-goal-milestone-row';
  row.innerHTML=`<input name="milestone" aria-label="Milestone ${id}" maxlength="200" placeholder="Enter a milestone"><input class="pms-milestone-due" name="milestoneDue" type="date" aria-label="Milestone ${id} due date optional" title="Optional due date"><button type="button" aria-label="Remove milestone ${id}" onclick="this.parentElement.remove()"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 10v7M14 10v7"/></svg></button>`;
  $('#pmsGoalMilestones').appendChild(row);
  if(id>1)row.querySelector('input').focus();
}
function pmsSearchGoalOwners(term){
  if(!pmsGoalCreate)return;
  const options=$('#pmsGoalOwnerOptions'),rows=pmsGoalCreateOwners().filter(e=>`${e[0]} ${e[1]} ${e[2]} ${e[3]}`.toLowerCase().includes(term.trim().toLowerCase()));
  options.hidden=false;$('#pmsGoalOwnerSearch').setAttribute('aria-expanded','true');
  options.innerHTML=rows.map(e=>`<button type="button" role="option" aria-selected="${pmsGoalCreate.owner===e[0]}" onclick="pmsSelectGoalOwner('${esc(e[0])}')"><span class="avatar">${initials(e[1])}</span><span><b>${esc(e[1])}</b><small>${esc(e[2])} · ${esc(e[0])}</small></span></button>`).join('')||'<p>No matching employees found.</p>';
  options.onkeydown=event=>{const buttons=[...options.querySelectorAll('button')],i=buttons.indexOf(document.activeElement);if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();buttons[(i+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus()}if(event.key==='Escape'){event.preventDefault();event.stopPropagation();pmsCloseGoalOwnerLookup();$('#pmsGoalOwnerSearch').focus();pmsCloseGoalOwnerLookup()}};
}
function pmsCloseGoalOwnerLookup(){const options=$('#pmsGoalOwnerOptions');if(options)options.hidden=true;$('#pmsGoalOwnerSearch')?.setAttribute('aria-expanded','false')}
function pmsSelectGoalOwner(id){const owner=pmsGoalCreateOwners().find(e=>e[0]===id);if(!owner||!pmsGoalCreate)return;pmsGoalCreate.owner=id;$('#pmsGoalOwnerSearch').value=owner[1];$('#pmsGoalOwnerSearch').setCustomValidity('');$('#pmsGoalOwnerAvatar').textContent=initials(owner[1]);pmsCloseGoalOwnerLookup()}
function pmsSaveCreatedGoal(event){
  event.preventDefault();
  if(!pmsGoalCreate||pmsGoalCreate.role!==viewRole)return;
  const form=$('#pmsCreateGoalForm'),fields=new FormData(form),owner=pmsGoalCreateOwners().find(e=>e[0]===pmsGoalCreate.owner),name=String(fields.get('name')||'').trim(),category=String(fields.get('category')||''),due=String(fields.get('due')||''),cycle=String(fields.get('cycle')||'');
  if(!owner){$('#pmsGoalOwnerSearch').setCustomValidity('Select an employee from the lookup.');$('#pmsGoalOwnerSearch').reportValidity();return}
  if(!name||!['Quality','Delivery','Growth','Collaboration'].includes(category)||!due||cycle&&!pmsGoalCreateCycles().some(c=>c.id===cycle)){$('#pmsGoalCreateError').textContent='Enter a goal name, category, deadline, and a permitted cycle.';return}
  const self=viewRole==='Employee';
  const milestoneDates=fields.getAll('milestoneDue'),milestoneValues=fields.getAll('milestone').map((value,i)=>({id:urUid('milestone'),title:String(value).trim(),due:String(milestoneDates[i]||''),done:false,completedAt:null}));
  if(milestoneValues.some(m=>m.due&&!m.title)){$('#pmsGoalCreateError').textContent='Enter a name for each milestone with a due date.';return}
  const milestones=milestoneValues.filter(m=>m.title);
  data.goals.push({id:pmsGoalId(),name,description:String(fields.get('description')||'').trim(),employee:owner[1],ownerId:owner[0],category,due,startDate:urToday,progress:0,status:'Active',milestones,trackingMode:milestones.length?'milestones':'manual',visibility:'owner-manager',cycleId:cycle||null,createdBy:urUser(),source:self?'self':'assigned',...(self?{}:{assignedBy:roleName()})});
  save();closeModal();render();toast('Goal saved');
}
const pmsGoalCreationBaseOpen=openGoal,pmsGoalCreationBaseSelf=pmsOpenSelfGoal,pmsGoalCreationBaseRole=roleGoal;
openGoal=function(id){if(id==null)return pmsCreateGoal();pmsGoalCreationBaseOpen(id);const goal=data.goals.find(g=>g.id===id),milestones=$('#pmsGoalForm textarea[name="milestones"]');if(goal&&milestones)milestones.value=pmsGoalMilestones(goal).map(m=>m.title).join('\n')};
pmsOpenSelfGoal=function(id){return id==null?(viewRole==='Employee'?pmsCreateGoal():undefined):pmsGoalCreationBaseSelf(id)};
roleGoal=function(id){return id==null?pmsCreateGoal():pmsGoalCreationBaseRole(id)};
$('#modal').addEventListener('close',()=>{$('#modal').classList.remove('pms-create-goal-dialog');pmsGoalCreate=null});
document.addEventListener('click',event=>{if(!event.target.closest('.pms-goal-owner-host'))pmsCloseGoalOwnerLookup()});

/* Milestone interactions enhance the existing table without changing its columns or toolbar. */
const pmsExpandedGoals=new Set();
let pmsMilestonePending=null,pmsMilestoneEditor=null;
function pmsMilestoneToday(){const now=new Date();return [now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-')}
pmsGoalMilestones=function(g){return (g.milestones||[]).map((value,index)=>{const m=typeof value==='string'?{title:value,done:false}:value;return {...m,id:m.id||`goal-${g.id}-milestone-${index}`,due:m.due||'',completedAt:m.completedAt||null,done:!!m.done}})};
function pmsMilestoneState(m){return m.done?(m.due&&m.completedAt&&m.completedAt>m.due?'Completed (Late)':'Completed'):m.due&&m.due<pmsMilestoneToday()?'Overdue':'Pending'}
function pmsMilestonePercent(ms){return ms.length?Math.round(ms.filter(m=>m.done).length/ms.length*100):0}
function pmsMilestoneGoal(id){return scopedGoals().find(g=>String(g.id)===String(id))}
function pmsCanCompleteMilestones(g){return !!g&&(urHr()||viewRole==='Manager'&&scopedGoals().includes(g)||viewRole==='Employee'&&pmsGoalOwner(g)===employeeId&&(pmsGoalStatus(g)!=='Completed'||g.trackingMode==='milestones'))}
function pmsCanManageMilestones(g){return pmsCanCompleteMilestones(g)&&(viewRole!=='Employee'||pmsOwnGoal(g))}
function pmsMilestoneSignature(ms){return JSON.stringify(ms.map(m=>[m.title,m.due||'',!!m.done,m.completedAt||null]))}
function pmsGoalMutationSnapshot(g){return JSON.stringify([g.progress,g.trackingMode,pmsMilestoneSignature(pmsGoalMilestones(g))])}
function pmsSaveGoalPatch(id,patch,after){
  const g=pmsMilestoneGoal(id);if(!pmsCanCompleteMilestones(g))return;
  const old=pmsGoalMilestones(g),ms=patch.milestones||old,changed=pmsMilestoneSignature(old)!==pmsMilestoneSignature(ms);
  if(patch.progress!==undefined&&(!Number.isFinite(patch.progress)||patch.progress<0||patch.progress>100))return;
  if(ms.some(m=>!m.title||!String(m.title).trim()))return;
  if(!pmsCanManageMilestones(g)){
    if(Object.keys(patch).some(key=>!['milestones','progress','updates'].includes(key)))return;
    if(ms.length!==old.length||ms.some(m=>!old.some(previous=>previous.id===m.id&&previous.title===m.title&&previous.due===m.due)))return;
  }
  const mode=g.trackingMode==='milestones'?'milestones':'manual',nextMode=ms.length&&(mode==='milestones'||changed)?'milestones':'manual';
  const nextProgress=nextMode==='milestones'?pmsMilestonePercent(ms):patch.progress??g.progress;
  const commit=()=>{const current=pmsMilestoneGoal(id);if(!pmsCanCompleteMilestones(current))return;Object.assign(current,patch,{milestones:ms,trackingMode:nextMode,progress:nextProgress});if(current.status!=='Pending Approval')current.status=nextProgress>=100?'Completed':'Active';save();closeModal();render();toast('Goal updated');if(after)after()};
  if(nextMode!==mode){
    pmsMilestonePending={id:String(id),role:viewRole,snapshot:pmsGoalMutationSnapshot(g),commit};
    modal(nextMode==='milestones'?'Switch to milestone progress?':'Switch to manual progress?',nextMode==='milestones'?'Confirm the tracking change before updating this goal.':'The final milestone will be removed.',`<div class="modalbody"><p>${nextMode==='milestones'?`The saved progress is ${g.progress}%. Milestone tracking will use completed milestones divided by all milestones and change progress to <b>${nextProgress}%</b>.`:`Without milestones, this goal will use manual progress. Its current progress of <b>${g.progress}%</b> will be retained.`}</p><p style="margin-top:12px">${esc(g.name)}</p></div>`,`<button onclick="pmsMilestonePending=null;closeModal();render()">Cancel</button><button class="primary" onclick="pmsConfirmGoalTracking()">${nextMode==='milestones'?'Switch and Save':'Remove and Use Manual Progress'}</button>`);
  }else commit();
}
function pmsConfirmGoalTracking(){const pending=pmsMilestonePending;pmsMilestonePending=null;if(!pending||pending.role!==viewRole)return;const g=pmsMilestoneGoal(pending.id);if(!g||pmsGoalMutationSnapshot(g)!==pending.snapshot){closeModal();render();toast('This goal changed. Open it again before saving.');return}pending.commit()}
$('#modal').addEventListener('close',()=>{if(pmsMilestonePending){pmsMilestonePending=null;render()}});
function pmsToggleGoalExpansion(id){const g=pmsMilestoneGoal(id);if(!g)return;const key=String(id);pmsExpandedGoals.has(key)?pmsExpandedGoals.delete(key):pmsExpandedGoals.add(key);render()}
function pmsSetMilestoneDone(id,milestoneId,done){const g=pmsMilestoneGoal(id);if(!pmsCanCompleteMilestones(g))return;const ms=pmsGoalMilestones(g),m=ms.find(m=>m.id===milestoneId);if(!m)return;m.done=done;m.completedAt=done?pmsMilestoneToday():null;pmsSaveGoalPatch(id,{milestones:ms})}
function pmsMilestoneStatusBadge(m){const state=pmsMilestoneState(m);return `<span class="pill ${state==='Overdue'?'red':state==='Completed (Late)'?'orange':m.done?'green':'neutral'}">${state}</span>`}
function pmsEnhanceGoalsListing(){
  if(page!=='Goals')return;
  const table=$('#content .pms-list-panel table'),body=table?.tBodies[0];if(!body)return;
  const employee=viewRole==='Employee',kind=employee?(pmsGoalsTab==='My Goals'?'mine':'assigned'):'admin',goals=pmsGoalPage(kind,pmsGoalRows(kind)).visible,parents=[...body.rows];
  parents.forEach((row,index)=>{
    const g=goals[index];if(!g||!row.cells[0])return;
    const key=String(g.id),name=row.cells[0].querySelector('b'),ms=pmsGoalMilestones(g),expanded=pmsExpandedGoals.has(key);
    if(!name)return;
    const title=document.createElement('span');title.className='pms-goal-expand-name';
    title.innerHTML=`<button class="pms-goal-chevron" type="button" aria-label="${expanded?'Collapse':'Expand'} milestones for ${esc(g.name)}" aria-expanded="${expanded}" onclick="pmsToggleGoalExpansion('${esc(key)}')"><svg viewBox="0 0 16 16" aria-hidden="true" style="transform:rotate(${expanded?90:0}deg)"><path d="m6 3 5 5-5 5"/></svg></button><button class="pms-goal-name-link" type="button" onclick="roleGoal('${esc(key)}')">${esc(g.name)}</button>`;
    // Existing goal identifiers are numeric; retain their type in the details action.
    title.querySelector('.pms-goal-name-link').onclick=()=>roleGoal(g.id);
    name.replaceWith(title);
    if(!expanded)return;
    let cursor=row;
    for(const m of ms){
      const child=document.createElement('tr');child.className='pms-milestone-child';
      const cells=Array.from({length:7},()=>''),allowed=pmsCanCompleteMilestones(g),manage=pmsCanManageMilestones(g);
      cells[0]=`<label class="pms-milestone-check"><input type="checkbox" ${m.done?'checked':''} ${allowed?'':'disabled'} aria-label="Complete milestone ${esc(m.title)}" onchange="pmsSetMilestoneDone('${esc(key)}','${esc(m.id)}',this.checked)"><span>${esc(m.title)}</span></label>`;
      cells[employee?3:4]=m.due?`${date(m.due)}${m.done&&m.completedAt?`<small>Completed ${date(m.completedAt)}</small>`:''}`:m.done&&m.completedAt?`<small>Completed ${date(m.completedAt)}</small>`:'<span class="urmuted">No due date</span>';
      cells[5]=pmsMilestoneStatusBadge(m);
      cells[6]=manage?`<button type="button" class="textbtn pms-milestone-more" aria-label="Actions for milestone ${esc(m.title)}" aria-haspopup="menu" onclick="pmsShowMilestoneMenu(event,'${esc(key)}','${esc(m.id)}')">⋯</button>`:'';
      child.innerHTML=cells.map((value,i)=>`<td${i===0?' class="urwrap"':''}>${value}</td>`).join('');cursor.after(child);cursor=child;
    }
    if(!ms.length||pmsCanManageMilestones(g)){
      const footer=document.createElement('tr');footer.className='pms-milestone-child pms-milestone-add-row';footer.innerHTML=`<td colspan="7">${!ms.length?'<span class="urmuted">0 milestones</span>':''}${pmsCanManageMilestones(g)?`<button type="button" class="textbtn" onclick="pmsEditMilestone('${esc(key)}')">+ Add Milestone</button>`:''}</td>`;cursor.after(footer);
    }
  });
}
function pmsShowMilestoneMenu(event,id,milestoneId){
  const g=pmsMilestoneGoal(id);if(!pmsCanManageMilestones(g))return;
  let menu=$('#pmsMilestoneMenu');if(!menu){menu=document.createElement('div');menu.id='pmsMilestoneMenu';menu.setAttribute('popover','auto');menu.setAttribute('role','menu');document.body.appendChild(menu)}
  menu.innerHTML=`<button role="menuitem" onclick="$('#pmsMilestoneMenu').hidePopover();pmsEditMilestone('${esc(String(id))}','${esc(milestoneId)}')">Edit milestone</button><button role="menuitem" onclick="$('#pmsMilestoneMenu').hidePopover();pmsRemoveMilestone('${esc(String(id))}','${esc(milestoneId)}')">Remove milestone</button>`;
  const rect=event.currentTarget.getBoundingClientRect();menu.style.left=Math.min(rect.left,window.innerWidth-190)+'px';menu.style.top=Math.min(rect.bottom+4,window.innerHeight-105)+'px';menu.showPopover();
}
function pmsEditMilestone(id,milestoneId){
  const g=pmsMilestoneGoal(id);if(!pmsCanManageMilestones(g))return;
  const m=pmsGoalMilestones(g).find(m=>m.id===milestoneId);if(milestoneId&&!m)return;
  pmsMilestoneEditor={id:String(id),milestoneId,role:viewRole};
  modal(m?'Edit Milestone':'Add Milestone',g.name,`<form id="pmsMilestoneForm"><div class="modalbody"><label>Milestone Name <span class="required">*</span><input name="title" required maxlength="200" placeholder="Enter a milestone" value="${esc(m?.title||'')}"></label><label style="margin-top:16px">Due Date <span class="urmuted">Optional</span><input name="due" type="date" value="${esc(m?.due||'')}"></label><p class="pms-milestone-help">Progress is calculated from completed milestones when milestone tracking is enabled.</p></div><div class="modalfoot"><button type="button" onclick="closeModal()">Cancel</button><button class="primary">Save Milestone</button></div></form>`);
  $('#pmsMilestoneForm').onsubmit=event=>{event.preventDefault();const draft=pmsMilestoneEditor,current=pmsMilestoneGoal(draft?.id);if(!draft||draft.role!==viewRole||!pmsCanManageMilestones(current))return;const fields=new FormData(event.target),title=String(fields.get('title')||'').trim();if(!title)return;const ms=pmsGoalMilestones(current);if(draft.milestoneId){const target=ms.find(m=>m.id===draft.milestoneId);if(!target)return;Object.assign(target,{title,due:String(fields.get('due')||'')})}else ms.push({id:urUid('milestone'),title,due:String(fields.get('due')||''),done:false,completedAt:null});pmsExpandedGoals.add(String(current.id));pmsSaveGoalPatch(current.id,{milestones:ms})};
}
function pmsRemoveMilestone(id,milestoneId){const g=pmsMilestoneGoal(id);if(!pmsCanManageMilestones(g))return;const m=pmsGoalMilestones(g).find(m=>m.id===milestoneId);if(!m)return;modal('Remove milestone?',g.name,`<div class="modalbody"><p>${esc(m.title)}</p><p style="margin-top:10px">Goal progress will be recalculated if milestone tracking is enabled.</p></div>`,`<button onclick="closeModal()">Cancel</button><button class="primary" onclick="pmsDoRemoveMilestone('${esc(String(id))}','${esc(milestoneId)}')">Remove Milestone</button>`)}
function pmsDoRemoveMilestone(id,milestoneId){const g=pmsMilestoneGoal(id);if(!pmsCanManageMilestones(g))return;pmsSaveGoalPatch(id,{milestones:pmsGoalMilestones(g).filter(m=>m.id!==milestoneId)})}

/* Keep the existing update dialogs; add deadline-aware rows and guard progress changes. */
function pmsInstallMilestoneEditor(id,kind){
  const g=pmsMilestoneGoal(id),form=$(kind==='assigned'?'#pmsAssignedGoalForm':kind==='self'?'#pmsSelfGoalForm':'#pmsGoalForm');
  if(!g||!form||!pmsCanCompleteMilestones(g))return;
  const manage=pmsCanManageMilestones(g),old=pmsGoalMilestones(g),textarea=form.querySelector('textarea[name="milestones"]'),progressInput=form.querySelector('input[name="progress"]');
  if(progressInput&&g.trackingMode==='milestones'){progressInput.readOnly=true;progressInput.setAttribute('aria-describedby','pmsMilestoneTrackingNote');const note=document.createElement('small');note.id='pmsMilestoneTrackingNote';note.textContent='Calculated automatically from completed milestones.';progressInput.after(note)}
  const host=document.createElement('div');host.className='pms-edit-milestones';host.dataset.manage=String(manage);host.dataset.goal=String(id);
  if(textarea){const label=textarea.parentElement;label.textContent='Milestones';label.appendChild(host)}else{const existing=form.querySelector('.pms-milestone-list');if(existing)existing.replaceWith(host);else return}
  function addRow(m={id:urUid('milestone'),title:'',due:'',done:false,completedAt:null}){
    const row=document.createElement('div');row.className='pms-edit-milestone-row';row.dataset.id=m.id;row.dataset.completedAt=m.completedAt||'';
    row.innerHTML=`<input type="checkbox" aria-label="Complete milestone" ${m.done?'checked':''}><input class="pms-edit-milestone-name" aria-label="Milestone name" maxlength="200" placeholder="Enter a milestone" value="${esc(m.title)}" ${manage?'':'readonly'}><input type="date" aria-label="Milestone due date optional" value="${esc(m.due)}" ${manage?'':'readonly'}>${manage?'<button type="button" class="textbtn" aria-label="Remove milestone" onclick="this.parentElement.remove()">×</button>':''}`;host.appendChild(row);
  }
  old.forEach(addRow);if(!old.length&&manage)addRow();
  if(manage){const add=document.createElement('button');add.type='button';add.className='textbtn';add.textContent='+ Add Milestone';add.onclick=()=>addRow();host.after(add)}
  form.onsubmit=event=>{
    event.preventDefault();const current=pmsMilestoneGoal(id);if(!pmsCanCompleteMilestones(current)||!form.reportValidity())return;
    const f=new FormData(form),rows=[...host.querySelectorAll('.pms-edit-milestone-row')],ms=rows.map(row=>{const previous=old.find(m=>m.id===row.dataset.id),done=row.querySelector('input[type="checkbox"]').checked;return {id:row.dataset.id,title:row.querySelector('.pms-edit-milestone-name').value.trim(),due:row.querySelector('input[type="date"]').value,done,completedAt:done?(previous?.done?previous.completedAt:pmsMilestoneToday()):null}});
    if(ms.some(m=>!m.title&&m.due)){toast('Enter a name for each milestone with a due date.');return}
    const progressValue=g.trackingMode==='milestones'?g.progress:Number(f.get('progress'));if(!Number.isFinite(progressValue)||progressValue<0||progressValue>100)return;
    const patch={milestones:ms.filter(m=>m.title),progress:progressValue};
    if(manage){const name=String(f.get('name')||'').trim(),due=String(f.get('due')||''),start=String(f.get('startDate')||g.startDate||'');if(!name||!due||start&&start>due){toast('Check the goal name and dates.');return}Object.assign(patch,{name,category:String(f.get('category')||g.category),due,...(kind==='self'?{startDate:start}:{})});if(kind==='admin'){const owner=pmsGoalCreateOwners().find(e=>e[1]===f.get('employee'));if(!owner){toast('Select a permitted goal owner.');return}patch.employee=owner[1];patch.ownerId=owner[0]}}
    const comment=String(f.get('comment')||'').trim();if(comment)patch.updates=[...(g.updates||[]),{by:roleName(),at:pmsMilestoneToday(),text:comment}];
    pmsSaveGoalPatch(id,patch);
  };
}
const pmsMilestoneOpenGoalBase=openGoal,pmsMilestoneSelfGoalBase=pmsOpenSelfGoal,pmsMilestoneAssignedGoalBase=pmsOpenAssignedGoal;
openGoal=function(id){pmsMilestoneOpenGoalBase(id);if(id!=null&&viewRole!=='Employee')pmsInstallMilestoneEditor(id,'admin')};
pmsOpenSelfGoal=function(id){pmsMilestoneSelfGoalBase(id);if(id!=null&&viewRole==='Employee')pmsInstallMilestoneEditor(id,'self')};
pmsOpenAssignedGoal=function(id){pmsMilestoneAssignedGoalBase(id);if(id!=null&&viewRole==='Employee')pmsInstallMilestoneEditor(id,'assigned')};
const pmsMilestoneRenderBase=render;
render=function(){pmsMilestoneRenderBase();pmsEnhanceGoalsListing()};
render();
